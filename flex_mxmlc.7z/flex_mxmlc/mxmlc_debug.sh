mxmlc -load-config D:/dev/nslm/flash/mxmlc_config/flex-config-debug.xml D:/dev/workspace/nslm/src/nslm.as -output D:/dev/workspace/nslm/bin-debug/nslm.swf
cp D:/dev/workspace/nslm/bin-debug/nslm.swf D:/dev/nslm/flash/RPGGame.swf
