mxmlc -load-config D:/dev/nslm/flash/mxmlc_config/flex-config.xml D:/dev/workspace/nslm/src/LMain.as -output D:/dev/workspace/nslm/bin-release/LMain.swf
cp D:/dev/workspace/nslm/bin-release/LMain.swf D:/dev/nslm/flash/RPGGame.swf
