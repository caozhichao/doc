#ifndef FLCCLIB__H__
#define FLCCLIB__H__

struct Player
{
	char c;
	int id;
	char name[20];
};

int c_int(int a);
float c_float(float a);
char* c_str(char *p);
char* c_str2(char str[]);
int c_int_array(const int* pInt,int len);
void c_struct(struct Player* p);
void c_struct2(struct Player p);

int c_bytes(const unsigned char* buffer, int bufferSize);

#endif


