#include "test.h"

int test_t1()
{
	return 10;
}
