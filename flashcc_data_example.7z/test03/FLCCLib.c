#include "FLCCLib.h"
#include <stdlib.h>
#include <string.h>



int c_int(int a)
{
	return a;
}

float c_float(float a)
{
	return a;
}

char* c_str(char *p)
{
	return p;
}

char* c_str2(char str[])
{
	int len = strlen(str);
	char* rp = NULL;
	char* p = (char*)malloc((len+1) * sizeof(str[0]));
	rp = p;
	while(*str != '\0')
	{
		*p++ = *str++;
	}
	//�����ַ���������'\0'
	*p = '\0';
	return rp;
}

int c_int_array(const int* pInt,int len)
{
	int i = 0;
	int sum = 0;

	
	while(i < len)
	{
		sum += *pInt;
		pInt++;
		i++;
	}
	

	return sum;
}

void c_struct(struct Player* p)
{
	//printf("%d,%s\n",p->id,p->name);
	p->id = 100;
	strcpy(p->name,"c_struct");
	//p->name = "c_struct";
}

void c_struct2(struct Player p)
{
	p.id = 100;
	strcpy(p.name,"c_struct2");
}

int c_bytes(const unsigned char* buffer, int bufferSize)
{
	return bufferSize;
}

